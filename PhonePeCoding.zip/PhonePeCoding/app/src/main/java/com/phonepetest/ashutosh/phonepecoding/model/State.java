package com.phonepetest.ashutosh.phonepecoding.model;

public enum State {
    UNREVEALED,
    REVEALED,
    TEMP_REVEALED
}

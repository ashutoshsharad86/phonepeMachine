package com.phonepetest.ashutosh.phonepecoding.viewmodel;

import android.arch.lifecycle.LiveData;
import android.arch.lifecycle.MutableLiveData;
import android.arch.lifecycle.ViewModel;
import android.os.Handler;
import android.os.Looper;

import com.phonepetest.ashutosh.phonepecoding.model.DataModel;
import com.phonepetest.ashutosh.phonepecoding.model.State;

import java.util.ArrayList;
import java.util.Collections;

public class DataViewModel extends ViewModel {
    private MutableLiveData<ArrayList<DataModel>> users;

    public void init(int level) {
        if (this.users != null) {
            return;
        }
        this.users = new MutableLiveData<ArrayList<DataModel>>();
        int rows = level, cols = 0;
        ArrayList<DataModel> list = new ArrayList<>();
        if(level % 2 == 0) {
            cols = level;
        } else {
            cols = level - 1;
        }

        for(int i = 0 ; i < rows * cols ; i++) {
            list.add(new DataModel("-----", i % (rows * cols / 2), State.UNREVEALED));
        }

        Collections.shuffle(list);
        users.setValue(list);
    }

    public LiveData<ArrayList<DataModel>> getUsers() {
        return this.users;
    }

    public boolean compute(DataModel item) {
        if(item.state == State.UNREVEALED) {
            item.state = State.TEMP_REVEALED;
            item.text = String.valueOf(item.value);
        } else {
            return false;
        }

        ArrayList<DataModel> list = users.getValue();
        // Search for previous revealed entities
        boolean revealed = false;
        for(DataModel model : list) {
            if(!model.equals(item) && model.state == State.TEMP_REVEALED) {
                if(model.value == item.value) {
                    model.state = State.REVEALED;
                    model.text = String.valueOf(model.value);
                    item.state = State.REVEALED;
                    item.text = String.valueOf(item.value);
                    revealed = true;
                } else {
                    model.state = State.UNREVEALED;
                    item.state = State.UNREVEALED;
                    Handler mainHandler = new Handler(Looper.getMainLooper());
                    Runnable myRunnable = new Runnable() {
                        @Override
                        public void run() {
                            model.text = "-----";
                            item.text = "-----";
                            users.setValue(list);
                        }
                    };
                    mainHandler.postDelayed(myRunnable, 300);
                }
                break;
            }
        }
        //MutableLiveData<ArrayList<DataModel>> data = new MutableLiveData<>();
        users.setValue(list);
        return checkGameComplete(list);
    }

    private boolean checkGameComplete (ArrayList<DataModel> data) {
        int size = data.size();
        boolean result = false;
        int totalRevealed = 0;
        for(DataModel model : data) {
            if(model.state == State.REVEALED) {
                totalRevealed ++ ;
            }
        }
        return totalRevealed == size ;
    }
}
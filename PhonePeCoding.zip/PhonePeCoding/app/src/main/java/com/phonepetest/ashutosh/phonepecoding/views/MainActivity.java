package com.phonepetest.ashutosh.phonepecoding.views;

import android.arch.lifecycle.ViewModelProviders;
import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.phonepetest.ashutosh.phonepecoding.R;
import com.phonepetest.ashutosh.phonepecoding.adapter.GameAdapter;
import com.phonepetest.ashutosh.phonepecoding.model.DataModel;
import com.phonepetest.ashutosh.phonepecoding.viewmodel.DataViewModel;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity implements GameAdapter.ItemListener {

    private DataViewModel viewModel;
    private GameAdapter adapter;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        int lev = 2;
        if(getIntent() != null) {
            lev = getIntent().getIntExtra("LEVEL_PHONEPE", 2);
        }
        RecyclerView recyclerView = findViewById(R.id.itemlist);
        TextView level = findViewById(R.id.level);
        Button nextLevel = findViewById(R.id.button2);
        final int nextLev = lev + 1;
        nextLevel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = getIntent();
                intent.putExtra("LEVEL_PHONEPE", nextLev);
                finish();
                startActivity(intent);
            }
        });
        viewModel = ViewModelProviders.of(this).get(DataViewModel.class);
        adapter = new GameAdapter(this, new ArrayList<>(), this);
        recyclerView.setAdapter(adapter);
        viewModel.init(lev);
        level.setText(String.valueOf(lev));
        viewModel.getUsers().observe(this, users -> {
            adapter.setValues(users);
            adapter.notifyDataSetChanged();
        });

        GridLayoutManager manager = new GridLayoutManager(this, 2, GridLayoutManager.VERTICAL, false);
        recyclerView.setLayoutManager(manager);
    }

    @Override
    public void onItemClick(DataModel item) {
        boolean result = viewModel.compute(item);
        if(result) {
            Toast.makeText(this ,"Game complete" , Toast.LENGTH_LONG).show();
        }
    }
}

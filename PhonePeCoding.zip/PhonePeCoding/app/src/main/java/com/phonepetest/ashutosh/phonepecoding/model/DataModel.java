package com.phonepetest.ashutosh.phonepecoding.model;

import java.util.Objects;

public class DataModel {

    public String text;
    public int value;
    public State state;

    public DataModel(String text, int value, State state )
    {
        this.text= text;
        this.value = value;
        this.state = state;
    }
}
